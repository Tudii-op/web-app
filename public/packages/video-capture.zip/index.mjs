import { jsxs as l, jsx as t, Fragment as h } from "react/jsx-runtime";
import d from "react";
import { invoke as w } from "@tauri-apps/api/core";
async function p(r, i = {}) {
  const n = await w("call_dll", {
    pluginName: "video_capture",
    function: r,
    args: JSON.stringify(i)
  });
  return JSON.parse(n);
}
function P() {
  const r = d.useRef(null), i = d.useRef(null), [n, u] = d.useState("idle"), [m, x] = d.useState(null), [b, a] = d.useState(null);
  return /* @__PURE__ */ l("div", { className: "flex flex-col h-full bg-[#0a0a0a] p-4 font-mono text-zinc-200", children: [
    /* @__PURE__ */ t("p", { className: "text-[10px] tracking-widest text-cyan-300 uppercase mb-4", children: "Video Capture" }),
    /* @__PURE__ */ t(
      "video",
      {
        ref: r,
        muted: !0,
        className: "w-full aspect-video bg-zinc-900 rounded mb-3 block"
      }
    ),
    /* @__PURE__ */ l("div", { className: "flex gap-2 mb-3", children: [
      n === "idle" && /* @__PURE__ */ t(
        "button",
        {
          onClick: async () => {
            try {
              const e = await navigator.mediaDevices.getDisplayMedia({
                video: !0,
                audio: !0
              });
              r.current && (r.current.srcObject = e, r.current.play()), u("previewing"), a(null), x(null);
            } catch (e) {
              a(String(e));
            }
          },
          className: "px-3 py-1.5 text-xs border border-cyan-300 text-cyan-300 rounded hover:bg-zinc-900 transition-colors",
          children: "Start Preview"
        }
      ),
      n === "previewing" && /* @__PURE__ */ l(h, { children: [
        /* @__PURE__ */ t(
          "button",
          {
            onClick: async () => {
              var f;
              const e = (f = r.current) == null ? void 0 : f.srcObject;
              if (!e) {
                a("Start preview first");
                return;
              }
              const s = await p("start", {});
              if (s.error) {
                a(s.error);
                return;
              }
              const o = new MediaRecorder(e, { mimeType: "video/webm; codecs=vp9" });
              o.ondataavailable = async (c) => {
                if (c.data.size === 0) return;
                const g = await c.data.arrayBuffer(), v = btoa(String.fromCharCode(...new Uint8Array(g)));
                await p("append_chunk", { data: v });
              }, o.onstop = async () => {
                const c = await p("finalize", {});
                c.error ? a(c.error) : x(c.path), u("previewing");
              }, o.start(500), i.current = o, u("recording"), a(null);
            },
            className: "px-3 py-1.5 text-xs border border-red-500 text-red-500 rounded hover:bg-zinc-900 transition-colors",
            children: "● Record"
          }
        ),
        /* @__PURE__ */ t(
          "button",
          {
            onClick: () => {
              var s;
              const e = (s = r.current) == null ? void 0 : s.srcObject;
              e == null || e.getTracks().forEach((o) => o.stop()), r.current && (r.current.srcObject = null), u("idle");
            },
            className: "px-3 py-1.5 text-xs border border-zinc-600 text-zinc-400 rounded hover:bg-zinc-900 transition-colors",
            children: "Stop Preview"
          }
        )
      ] }),
      n === "recording" && /* @__PURE__ */ t(
        "button",
        {
          onClick: () => {
            var e;
            (e = i.current) == null || e.stop(), i.current = null;
          },
          className: "px-3 py-1.5 text-xs border border-orange-500 text-orange-500 rounded hover:bg-zinc-900 transition-colors",
          children: "■ Stop Recording"
        }
      )
    ] }),
    n === "recording" && /* @__PURE__ */ t("p", { className: "text-[11px] text-red-500 tracking-widest animate-pulse mb-2", children: "● RECORDING" }),
    m && /* @__PURE__ */ l("p", { className: "text-[11px] text-cyan-300 break-all mb-2", children: [
      "Saved → ",
      m
    ] }),
    b && /* @__PURE__ */ l("p", { className: "text-[11px] text-red-400 mb-2", children: [
      "Error: ",
      b
    ] })
  ] });
}
export {
  P as default
};
