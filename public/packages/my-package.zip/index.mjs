import { jsxs as m, jsx as t } from "react/jsx-runtime";
import a from "react";
import { invoke as d } from "@tauri-apps/api/core";
async function p(r, l) {
  const n = await d("call_dll", {
    pluginName: "my-package",
    function: r,
    args: JSON.stringify(l)
  });
  return JSON.parse(n);
}
function N() {
  const [r, l] = a.useState(0), [n, o] = a.useState(0), [s, i] = a.useState(null), [u, c] = a.useState(null);
  return /* @__PURE__ */ m("div", { children: [
    /* @__PURE__ */ t("h1", { children: "Calculator Plugin" }),
    /* @__PURE__ */ t(
      "input",
      {
        type: "number",
        value: r,
        onChange: (e) => l(Number(e.target.value))
      }
    ),
    "+",
    /* @__PURE__ */ t(
      "input",
      {
        type: "number",
        value: n,
        onChange: (e) => o(Number(e.target.value))
      }
    ),
    /* @__PURE__ */ t("button", { onClick: async () => {
      try {
        const e = await p("add", { a: r, b: n });
        if (e.error) throw new Error(e.error);
        i(e.result), c(null);
      } catch (e) {
        c(String(e));
      }
    }, children: "Calculate" }),
    /* @__PURE__ */ t("h1", { children: s ?? "?" }),
    u && /* @__PURE__ */ t("p", { style: { color: "red" }, children: u })
  ] });
}
export {
  N as default
};
